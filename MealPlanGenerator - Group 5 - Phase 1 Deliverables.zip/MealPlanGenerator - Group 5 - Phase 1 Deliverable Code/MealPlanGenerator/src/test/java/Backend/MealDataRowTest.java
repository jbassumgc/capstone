package Backend;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MealDataRowTest {

	@Test
	void testMealDataRow() {
		fail("Not yet implemented");
	}

	@Test
	void testGetData() {
		fail("Not yet implemented");
	}

	@Test
	void testGetColumn() {
		fail("Not yet implemented");
	}

	@Test
	void testReset() {
		fail("Not yet implemented");
	}

}
