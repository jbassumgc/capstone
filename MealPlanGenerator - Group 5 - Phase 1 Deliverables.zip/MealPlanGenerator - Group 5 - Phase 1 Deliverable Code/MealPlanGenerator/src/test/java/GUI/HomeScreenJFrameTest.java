package GUI;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HomeScreenJFrameTest {

	@Test
	void testHomeScreenJFrame() {
		fail("Not yet implemented");
	}

	@Test
	void testHomeScreenJFrameString() {
		fail("Not yet implemented");
	}

	@Test
	void testHomeScreenJFrameStringBoolean() {
		fail("Not yet implemented");
	}

	@Test
	void testInitGUI() {
		fail("Not yet implemented");
	}

}
