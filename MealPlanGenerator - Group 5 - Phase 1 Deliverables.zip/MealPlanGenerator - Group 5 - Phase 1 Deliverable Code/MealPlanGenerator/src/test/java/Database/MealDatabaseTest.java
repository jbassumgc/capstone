package Database;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MealDatabaseTest {

	@Test
	void testMealDatabase() {
		fail("Not yet implemented");
	}

	@Test
	void testAddMeal() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDatabaseCount() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDatabaseName() {
		fail("Not yet implemented");
	}

	@Test
	void testBuildMealArrays() {
		fail("Not yet implemented");
	}

	@Test
	void testRebuildMealArrays() {
		fail("Not yet implemented");
	}

	@Test
	void testGetRandomMeal() {
		fail("Not yet implemented");
	}

	@Test
	void testGetIngredients() {
		fail("Not yet implemented");
	}

	@Test
	void testGetIngredientAmounts() {
		fail("Not yet implemented");
	}

	@Test
	void testGetIngredientMeasurements() {
		fail("Not yet implemented");
	}

	@Test
	void testGetMealName() {
		fail("Not yet implemented");
	}

	@Test
	void testCapitalizeName() {
		fail("Not yet implemented");
	}

	@Test
	void testResetMealPlan() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAllMeals() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEditableMealProperties() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEditableIngredientProperties() {
		fail("Not yet implemented");
	}

	@Test
	void testEditMealProperty() {
		fail("Not yet implemented");
	}

	@Test
	void testGetMealIngredients() {
		fail("Not yet implemented");
	}

	@Test
	void testRemoveIngredient() {
		fail("Not yet implemented");
	}

	@Test
	void testAddIngredient() {
		fail("Not yet implemented");
	}

	@Test
	void testChangeIngredient() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteMeal() {
		fail("Not yet implemented");
	}

	@Test
	void testGetMealProperty() {
		fail("Not yet implemented");
	}

	@Test
	void testGetIngredientProperty() {
		fail("Not yet implemented");
	}

}
