package Backend;

import java.awt.Dimension;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import Database.MealDatabase;

/*
  Meal Plan Generator
  CMSC 495 7381
  Group 5 - Joseph Awonusi, Jordan Bass, Daniel Beck, Zach Burke

  This class holds the meal plan and ingredient list for display.
*/

public class MealPlan {
	private final MealDatabase mealDatabase;
	private final boolean[] mealsIncluded;
    private final boolean[] outputOptions;
	private final int daysOfMeals;
	private final ArrayList<String> selectedMeals;
	private ArrayList<String> selectedMealIngredients;
	private List<String> selectedMealIngredientMeasurements;
	private List<String> selectedMealIngredientAmounts;
	private final int duplicatePeriod;
    private final String selectedDayOfWeek;
    private final int daysPerList;

	// Constructor that establishes the options and number of meals and duplication
	// period
	public MealPlan(MealDatabase mealDatabase, boolean[] mealsIncluded, boolean[] outputOptions,
            int daysOfMeals, int duplicatePeriod, String selectedDayOfWeek, int daysPerList) {
        this.selectedMeals = new ArrayList<>();
		this.mealDatabase = mealDatabase;
		this.mealsIncluded = mealsIncluded;
        this.outputOptions = outputOptions;
		this.daysOfMeals = daysOfMeals;
		this.duplicatePeriod = duplicatePeriod;
        this.selectedDayOfWeek = selectedDayOfWeek;
        this.daysPerList = daysPerList;
	}

	// Creates random numbers and requests a random meal from the meal database
	public void generatePlan() {
        int mealsPerDay = 0;
        int listDelineation = 0;
        if(mealsIncluded[0])
            listDelineation++;
        if(mealsIncluded[1])
            listDelineation++;
        if(mealsIncluded[2])
            listDelineation++;
        listDelineation *= daysPerList;
        
		if ((mealsIncluded[0] || mealsIncluded[1] || mealsIncluded[2]) &&
                (outputOptions[0] || mealsIncluded[1] || mealsIncluded[2])) {
			mealDatabase.buildMealArrays();
            for(int counter = 0; counter < daysOfMeals; counter++) {
                if(duplicatePeriod > 0) {
                  if((counter + 1) % duplicatePeriod == 0 && duplicatePeriod > 0)
                            mealDatabase.rebuildMealArrays();
                }
                mealsPerDay = 0;
                if(mealsIncluded[0]) {
                        int randomNumber = ThreadLocalRandom.current().nextInt(0, mealDatabase.breakfastMeals.size());
                        selectedMeals.add(mealDatabase.getRandomMeal(1, randomNumber));
                        mealsPerDay++;
                    }
                    if (mealsIncluded[1]) {
                        int randomNumber = ThreadLocalRandom.current().nextInt(0, mealDatabase.lunchMeals.size());
                        selectedMeals.add(mealDatabase.getRandomMeal(2, randomNumber));
                        mealsPerDay++;
                    }
                    if (mealsIncluded[2]) {
                        int randomNumber = ThreadLocalRandom.current().nextInt(0, mealDatabase.dinnerMeals.size());
                        selectedMeals.add(mealDatabase.getRandomMeal(3, randomNumber));
                        mealsPerDay++;
                    }
                }

			// Displays the meal plan
			int day = 1;
			String displayMealPlan = "";
			int selectedMealCounter = 0;
            String[] dayOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
            int dayOfWeekCounter;
            switch(selectedDayOfWeek) {
                case "Monday":
                    dayOfWeekCounter = 1;
                    break;
                case "Tuesday":
                    dayOfWeekCounter = 2;
                    break;
                case "Wednesday":
                    dayOfWeekCounter = 3;
                    break;
                case "Thursday":
                    dayOfWeekCounter = 4;
                    break;
                case "Friday":
                    dayOfWeekCounter = 5;
                    break;
                case "Saturday":
                    dayOfWeekCounter = 6;
                    break;
                default:
                    dayOfWeekCounter = 0;
                    break;
            }
			while (selectedMealCounter < selectedMeals.size()) {
				displayMealPlan += "Day " + day + " - " + dayOfWeek[dayOfWeekCounter % 7] + "\n    ";
				if (mealsIncluded[0]) {
					displayMealPlan += "Breakfast - " + mealDatabase.getMealName(selectedMeals.get(selectedMealCounter))
							+ mealDatabase.checkFavorite(selectedMeals.get(selectedMealCounter)) + "\n    ";
					selectedMealCounter++;
				}
				if (mealsIncluded[1]) {
					displayMealPlan += "Lunch - " + mealDatabase.getMealName(selectedMeals.get(selectedMealCounter))
							+ mealDatabase.checkFavorite(selectedMeals.get(selectedMealCounter)) + "\n    ";
					selectedMealCounter++;
				}
				if (mealsIncluded[2]) {
					displayMealPlan += "Dinner - " + mealDatabase.getMealName(selectedMeals.get(selectedMealCounter))
							+ mealDatabase.checkFavorite(selectedMeals.get(selectedMealCounter)) + "\n    ";
					selectedMealCounter++;
				}
                displayMealPlan += "\n";
                dayOfWeekCounter++;
				day++;
			}
            
            ArrayList<String> combinedShoppingList = new ArrayList<>();
            for(int delineationCounter = 0; delineationCounter < selectedMeals.size(); delineationCounter += listDelineation) { 
                int endDay = delineationCounter + listDelineation;
                if(selectedMeals.size() > endDay) {
                    selectedMealIngredients = mealDatabase.getIngredients(selectedMeals.subList(delineationCounter, endDay));
                    selectedMealIngredientMeasurements = mealDatabase.getIngredientMeasurements(selectedMeals.subList(delineationCounter, endDay));
                    selectedMealIngredientAmounts = mealDatabase.getIngredientAmounts(selectedMeals.subList(delineationCounter, endDay));
                }
                else {
                    endDay = selectedMeals.size();
                    selectedMealIngredients = mealDatabase.getIngredients(selectedMeals.subList(delineationCounter, endDay));
                    selectedMealIngredientMeasurements = mealDatabase.getIngredientMeasurements(selectedMeals.subList(delineationCounter, endDay));
                    selectedMealIngredientAmounts = mealDatabase.getIngredientAmounts(selectedMeals.subList(delineationCounter, endDay));
                }
                ArrayList<String> combinedShoppingListDelineated = getShoppingList(selectedMealIngredients);
                combinedShoppingList.add("List " + (delineationCounter / listDelineation + 1) + 
                        " (Days " + (delineationCounter / mealsPerDay + 1) + " through " + (endDay / mealsPerDay) +  "):"); 
                for(String listItem : combinedShoppingListDelineated)
                    combinedShoppingList.add("    " + listItem);
                combinedShoppingList.add("\n");
            }
			// Displays the shopping list
			String displayGroceryList = "";
			for (int counter = 0; counter < combinedShoppingList.size(); counter++) {
                if(!combinedShoppingList.get(counter).isEmpty())
                    displayGroceryList += "\n";
                displayGroceryList += combinedShoppingList.get(counter);
			}
            displayGroceryList = displayGroceryList.trim();
            if(outputOptions[0]) {
                String fileName = "";
                try { 
                    JFileChooser outputFile = new JFileChooser();
                    File workingDirectory = new File(System.getProperty("user.dir"));
                    outputFile.setSelectedFile(new File(new SimpleDateFormat("yyyy-MM-dd HHmmss").format(new Date()) + " Meal Plan.txt"));
                    outputFile.setCurrentDirectory(workingDirectory);
                    outputFile.setFileFilter(new FileNameExtensionFilter("txt file","txt"));
                    int returnVal = outputFile.showSaveDialog(null);
                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        File file = outputFile.getSelectedFile();
                        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                            writer.write("---Meal Plan---\n* Denotes Favorited Meal\n\n\n" + displayMealPlan);
                            writer.write("\n\n---Grocery List---\n\n" + displayGroceryList);
                        }
                        fileName = file.getName();
                        
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error writing to file "
                    + fileName, "IO Error", JOptionPane.ERROR_MESSAGE);
                } 
            }         
            
            if(outputOptions[2]) {
                String fileName = "";
                try {
                    JFileChooser outputFile = new JFileChooser();
                    File workingDirectory = new File(System.getProperty("user.dir"));
                    outputFile.setSelectedFile(new File(new SimpleDateFormat("yyyy-MM-dd HHmmss").format(new Date()) + " Meal Plan.pdf"));
                    outputFile.setCurrentDirectory(workingDirectory);
                    outputFile.setFileFilter(new FileNameExtensionFilter("pdf file","pdf"));
                    int returnVal = outputFile.showSaveDialog(null);
                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        File file = outputFile.getSelectedFile();
                        Document document = new Document();
                        PdfWriter.getInstance(document, new FileOutputStream(file));
                        document.open();
                        Paragraph planTitle = new Paragraph("Meal Plan", FontFactory.getFont(FontFactory.COURIER, 18, BaseColor.BLACK));
                        planTitle.setAlignment(Element.ALIGN_CENTER);
                        document.add(planTitle);
                        Paragraph planFootnote = new Paragraph("* Denotes Favorited Meal\n", FontFactory.getFont(FontFactory.COURIER, 8, BaseColor.BLACK));
                        planFootnote.setAlignment(Element.ALIGN_CENTER);
                        document.add(planFootnote);
                        
                        Paragraph mealPlan = new Paragraph(displayMealPlan, FontFactory.getFont(FontFactory.COURIER, 12, BaseColor.BLACK));
                        document.add(mealPlan);
                        
                        document.newPage();
                        
                        Paragraph groceryTitle = new Paragraph("Grocery List\n", FontFactory.getFont(FontFactory.COURIER, 18, BaseColor.BLACK));
                        groceryTitle.setAlignment(Element.ALIGN_CENTER);
                        document.add(groceryTitle);
                        
                        Paragraph groceryList = new Paragraph(displayGroceryList, FontFactory.getFont(FontFactory.COURIER, 12, BaseColor.BLACK));
                        document.add(groceryList);
                        
                        document.close();
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error writing to file "
                    + fileName, "IO Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            if(outputOptions[1]) {
                JTextArea textArea = new JTextArea(displayMealPlan);
                textArea.setEditable(false);
                textArea.setOpaque(false);
                JScrollPane scrollPane = new JScrollPane(textArea);
                scrollPane.setPreferredSize(new Dimension(300, 550));
                JOptionPane.showMessageDialog(null, scrollPane, "Meal Plan   * Denotes Favorited Meal", JOptionPane.PLAIN_MESSAGE);
                textArea.setText(displayGroceryList);
                scrollPane = new JScrollPane(textArea);
                scrollPane.setPreferredSize(new Dimension(300, 600));
                JOptionPane.showMessageDialog(null, scrollPane, "Grocery List", JOptionPane.PLAIN_MESSAGE);
            }
			mealDatabase.resetMealPlan();
		} 
        else
			JOptionPane.showMessageDialog(null, "You must select at least one meal of the day option"
                    + " and at least one output option!", "IO Error",
					JOptionPane.ERROR_MESSAGE);
	}

	// Combines duplicate ingredients with like measurements
	private ArrayList<String> getShoppingList(ArrayList<String> ingredientList) {
		ArrayList<String> combinedShoppingList = new ArrayList<>();
		ArrayList<String> tempList = new ArrayList<>();
		DecimalFormat format = new DecimalFormat("#,###.###");
		for (int countX = 0; countX < ingredientList.size(); countX++) {
			double totalIngredientCount = Double.parseDouble(selectedMealIngredientAmounts.get(countX));
			for (int countY = countX + 1; countY < ingredientList.size(); countY++) {
				if (ingredientList.get(countX).equals(ingredientList.get(countY))) {
					if (selectedMealIngredientMeasurements.get(countX)
							.equals(selectedMealIngredientMeasurements.get(countY))) {
						totalIngredientCount += Double.parseDouble(selectedMealIngredientAmounts.get(countY));
					}
				}
			}
			if (!tempList.contains(ingredientList.get(countX))) {
				tempList.add(ingredientList.get(countX));
				combinedShoppingList.add(format.format(totalIngredientCount) + " "
						+ selectedMealIngredientMeasurements.get(countX) + " " + ingredientList.get(countX));
			}
		}
		return combinedShoppingList;
	}
}
