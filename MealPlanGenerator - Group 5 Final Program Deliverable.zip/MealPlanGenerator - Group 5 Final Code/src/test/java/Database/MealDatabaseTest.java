package Database;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import TestLog.WriteToTestLogFile;
import Utilities.RandomNumber;

class MealDatabaseTest {
	//Set the database for all testing
	MealDatabase md = new MealDatabase("test-database", false);
	WriteToTestLogFile wtf = new WriteToTestLogFile();

	@Test
	//Test that retrieves database count of each meal type
	void testGetDatabaseCount() {
		int[] result = md.getDatabaseCount();
		
		assertFalse(result.length == 0);
		
//		System.out.println("GetDatabaseCount test passed outputting "
//				+ result[0] + " Breakfasts, "
//				+ result[1] + " Lunches, "
//				+ result[2] + " Dinners, ");
		
		wtf.fileWrite("GetDatabaseCount test passed outputting "
				+ result[0] + " Breakfasts, "
				+ result[1] + " Lunches & "
				+ result[2] + " Dinners");
	}
	
	@Test
	//Test that retrieves database total meals
	void testGetDatabaseCountTotal() {
		int[] result = md.getDatabaseCount();
		
		int totalToTest = result[0] + result[1] + result[2];
		
		assertEquals(totalToTest, result[3]);
		
//		System.out.println("GetDatabaseCountTotal test passed outputting "
//				+ result[3]);
		
		wtf.fileWrite("GetDatabaseCountTotal test passed outputting "
				+ result[3]);
	}

	@Test
	//Test that retrieves database name
	void testGetDatabaseName() {
		String result = md.getDatabaseName();

		assertEquals("test-database", result);
		
//		System.out.println("GetDatabaseName test passed outputting "
//				+ result);
		
		wtf.fileWrite("GetDatabaseName test passed outputting "
				+ result);
	}

	@Test
	//Test that retrieves random breakfast meal
	void testGetRandomBreakfast() {
		md.buildMealArrays();
		int count = md.breakfastMeals.size();
		RandomNumber rn = new RandomNumber(count-1);
		int num = rn.getNewNum();
		
		String result = md.getRandomMeal(1, num);
		
		assertNotNull(result);
		
//		System.out.println("GetRandomBreakfast test passed outputting Breakfast meal: "
//				+ result);
		
		wtf.fileWrite("GetRandomBreakfast test passed outputting Breakfast meal: "
				+ result);
	}
	
	@Test
	//Test that retrieves random lunch meal
	void testGetRandomLunch() {
		md.buildMealArrays();
		int count = md.lunchMeals.size();
		RandomNumber rn = new RandomNumber(count-1);
		int num = rn.getNewNum();
		
		String result = md.getRandomMeal(2, num);
		
		assertNotNull(result);
		
//		System.out.println("GetRandomLunch test passed outputting Lunch meal: "
//				+ result);
		
		wtf.fileWrite("GetRandomLunch test passed outputting Lunch meal: "
				+ result);
	}
	
	@Test
	//Test that retrieves random dinner meal
	void testGetRandomDinner() {
		md.buildMealArrays();
		int count = md.dinnerMeals.size();
		RandomNumber rn = new RandomNumber(count-1);
		int num = rn.getNewNum();
		
		String result = md.getRandomMeal(3, num);
		
		assertNotNull(result);
		
//		System.out.println("GetRandomDinner test passed outputting Dinner meal: "
//				+ result);
		
		wtf.fileWrite("GetRandomDinner test passed outputting Dinner meal: "
				+ result);
	}

	@Test
	//get ingredients of Avacodo Toast
	void testGetIngredients() {
		md.buildMealArrays();
		
		ArrayList<String> meals = new ArrayList<>();
		meals.add(md.getRandomMeal(1, 1));
		
		ArrayList<String> result = md.getIngredients(meals);
		ArrayList<String> expectedValue = new ArrayList<>();
		
		expectedValue.add("Avacado");
		expectedValue.add("Bread");
		expectedValue.add("Egg");	
		
		assertEquals(expectedValue, result);
		
//		System.out.println("GetIngredients test passed outputting ingredients for Avacado Toast: "
//				+ result);
		
		wtf.fileWrite("GetIngredients test passed outputting ingredients for Avacado Toast: "
				+ result);
	}

	@Test
	//get ingredient amounts of Avacado Toast
	void testGetIngredientAmounts() {
		md.buildMealArrays();
		
		ArrayList<String> meals = new ArrayList<>();
		meals.add(md.getRandomMeal(1, 1));
		
		ArrayList<String> result = md.getIngredientAmounts(meals);
		ArrayList<String> expectedValue = new ArrayList<>();
		
		expectedValue.add("1.0");
		expectedValue.add("1.0");
		expectedValue.add("1.0");	
		
		assertEquals(expectedValue, result);
		
//		System.out.println("GetIngredientAmounts test passed outputting ingredients count for Avacado Toast: "
//				+ result);
		
		wtf.fileWrite("GetIngredientAmounts test passed outputting ingredients count for Avacado Toast: "
				+ result);
	}

	@Test
	//get ingredient measurements of Avacado Toast
	void testGetIngredientMeasurements() {
		md.buildMealArrays();
		
		ArrayList<String> meals = new ArrayList<>();
		meals.add(md.getRandomMeal(1, 1));
		
		ArrayList<String> result = md.getIngredientMeasurements(meals);
		ArrayList<String> expectedValue = new ArrayList<>();
		
		expectedValue.add("Count");
		expectedValue.add("Count");
		expectedValue.add("Count");	
		
		assertEquals(expectedValue, result);
		
//		System.out.println("GetIngredientMeasurements test passed outputting ingredient measurements for Avacado Toast: "
//				+ result);
		
		wtf.fileWrite("GetIngredientMeasurements test passed outputting ingredient measurements for Avacado Toast: "
				+ result);
	}

	@Test
	void testGetMealName() {
		md.buildMealArrays();
		
		String expectedValue = "Avacado Toast";
		
		String result = md.getMealName("AvacadoToast4");
		
		assertEquals(expectedValue, result);
		
//		System.out.println("GetMealName test passed outputting meal name: "
//				+ result);
		
		wtf.fileWrite("GetMealName test passed outputting meal name: "
				+ result);
	}

	@Test
	void testCheckFavorite() {
		md.buildMealArrays();
		
		String expectedValue = "*";
		
		String result = md.checkFavorite("AvacadoToast4");
		
		assertEquals(expectedValue, result);
		
//		System.out.println("CheckFavorite test passed outputting " + result 
//				+ " for Avacado Toast");
		
		wtf.fileWrite("CheckFavorite test passed outputting " + result 
				+ " for Avacado Toast");
	}

	@Test
	void testCapitalizeName() {
		md.buildMealArrays();
		
		String expectedValue = "Eggs";
		
		String result = md.capitalizeName("eggs");
		
		assertEquals(expectedValue, result);
		
//		System.out.println("CapitalizeName test passed changing eggs to " + result);
		
		wtf.fileWrite("CapitalizeName test passed changing eggs to " + result);
	}

	@Test
	void testGetAllMeals() {
		md.buildMealArrays();
		
		Object[] result = md.getAllMealIDs();
		
		assertNotNull(result);
		
		String stringToWrite = "";
		
//		System.out.print("GetAllMeals test passed listing: ");
//		for (int j = 0; j < result.length-1; j++) {
//			System.out.print(result[j] + ", ");
//		}
//		System.out.println(result[result.length-1]);
		
		stringToWrite += "GetAllMeals test passed listing: ";
		for (int j = 0; j < result.length-1; j++) {
			stringToWrite += result[j] + ", ";
		}
		stringToWrite += result[result.length-1];
		
		wtf.fileWrite(stringToWrite);
	}

	@Test
	void testGetAllMealIDs() {
		md.buildMealArrays();
		
		Object[] result = md.getAllMealIDs();
		
		assertNotNull(result);
		
		String stringToWrite = "";
		
//		System.out.print("GetAllMealIDs test passed listing: ");
//		for (int j = 0; j < result.length-1; j++) {
//			System.out.print(result[j] + ", ");
//		}
//		System.out.println(result[result.length-1]);
		
		stringToWrite += "GetAllMealIDs test passed listing: ";
		for (int j = 0; j < result.length-1; j++) {
			stringToWrite += result[j] + ", ";
		}
		stringToWrite += result[result.length-1];
		
		wtf.fileWrite(stringToWrite);
	}

	@Test
	void testGetEditableMealProperties() {
		md.buildMealArrays();
		
		Object[] result = md.getEditableMealProperties();
		
		assertNotNull(result);
		
		String stringToWrite = "";
		
//		System.out.print("GetEditableMealProperties test passed listing: ");
//		for (int j = 0; j < result.length-1; j++) {
//			System.out.print(result[j] + ", ");
//		}
//		System.out.println(result[result.length-1]);
		
		stringToWrite += "GetEditableMealProperties test passed listing: ";
		for (int j = 0; j < result.length-1; j++) {
			stringToWrite += result[j] + ", ";
		}
		stringToWrite += result[result.length-1];
		
		wtf.fileWrite(stringToWrite);
	}

	@Test
	void testGetEditableIngredientProperties() {
		md.buildMealArrays();
		
		Object[] result = md.getEditableIngredientProperties("AvacadoToast4");
		
		assertNotNull(result);
		
		String stringToWrite = "";
		
//		System.out.print("GetEditableIngredientProperties test passed listing ingredients for Avacado Toast: ");
//		for (int j = 0; j < result.length-1; j++) {
//			System.out.print(result[j] + ", ");
//		}
//		System.out.println(result[result.length-1]);
		
		stringToWrite += "GetEditableIngredientProperties test passed listing ingredients for Avacado Toast: ";
		for (int j = 0; j < result.length-1; j++) {
			stringToWrite += result[j] + ", ";
		}
		stringToWrite += result[result.length-1];
		
		wtf.fileWrite(stringToWrite);
	}

	@Test
	void testGetMealPropertyValue() {
		md.buildMealArrays();
		
		String expectedValue = "200";
		
		String result = md.getMealPropertyValue("AvacadoToast4", "calories");
		
		assertEquals(expectedValue, result);
		
//		System.out.println("GetMealPropertyValue test passed getting CALORIES" 
//		+ " property value of Avacado Toast: " + result);
		
		wtf.fileWrite("GetMealPropertyValue test passed getting CALORIES" 
				+ " property value of Avacado Toast: " + result);
	}

	@Test
	void testGetIngredientPropertyValue() {
		md.buildMealArrays();
		
		String expectedValue = "Bread";
		
		String result = md.getIngredientPropertyValue("AvacadoToast4", "Bread", "ingredient");
		
		assertEquals(expectedValue, result);
		
//		System.out.println("GetIngredientPropertyValue test passed getting ingredient: " 
//		+ result);
		
		wtf.fileWrite("GetIngredientPropertyValue test passed getting ingredient: " 
				+ result);
	}

	@Test
	void testGetMealIngredients() {
		
		md.buildMealArrays();
		
		Object[] result = md.getMealIngredients("AvacadoToast4");
		
		assertNotNull(result);
		
		String stringToWrite = "";
		
//		System.out.print("GetMealIngredients test passed listing ingredients for Avacado Toast: ");
//		for (int j = 0; j < result.length-1; j++) {
//			System.out.print(result[j] + ", ");
//		}
//		System.out.println(result[result.length-1]);
		
		stringToWrite += "GetMealIngredients test passed listing ingredients for Avacado Toast: ";
		for (int j = 0; j < result.length-1; j++) {
			stringToWrite += result[j] + ", ";
		}
		stringToWrite += result[result.length-1];
		
		wtf.fileWrite(stringToWrite);
	}

	@Test
	void testGetMealProperty() {
		md.buildMealArrays();
		
		String expectedValue = "200";
		
		String result = md.getMealProperty("AvacadoToast4", "calories");
		
		assertEquals(expectedValue, result);
		
//		System.out.println("GetMealProperty test passed getting calorie property of Avacado Toast: " 
//		+ result);
		
		wtf.fileWrite("GetMealProperty test passed getting calorie property of Avacado Toast: " 
				+ result);
	}

	@Test
	void testGetIngredientProperty() {
		md.buildMealArrays();
		
		String expectedValue = "Bread";
		
		String result = md.getIngredientProperty("AvacadoToast4", "ingredient", "Bread");
		
		assertEquals(expectedValue, result);
		
//		System.out.println("GetIngredientProperty test passed getting calorie property of Avacado Toast: " 
//		+ result);
		
		wtf.fileWrite("GetIngredientProperty test passed getting calorie property of Avacado Toast: " 
				+ result);
	}

}
