package TestLog;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;


public class WriteToTestLogFile
{
	/**
     * *************************************************************
     * Global Variables
     * **************************************************************
     */
    private String writeToFile;
    private String timeStampData;
    
    // 2021-03-24 16:48:05
    private static final SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	//Creates a time stamp from time stamp class
    Timestamp timestamp = new Timestamp(System.currentTimeMillis());

    /***************************************************************
     * Writes to the log when user tries to access the system
     */
    public WriteToTestLogFile() 
    {
        //Variables
    	 
//    	fileWrite();
    }
	
	public void fileWrite(String writeToFile) 
	{
		this.writeToFile = writeToFile;
		//looks for the log.txt file, creates one if one does not exist
        try (FileWriter fw = new FileWriter("TestLog.txt", true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw))
        {
        	//logs successful attempt
        	this.timeStampData = sdf3.format(timestamp);
        	out.println(timeStampData + " - " + this.writeToFile);
        } 
        catch (IOException e)    
        {
            System.out.println("Issue reading the Test Log file." + e.getMessage());
        } 
	}
	
	public String getTimestampData()
	{
		return timeStampData;
	}
}