package Database;

/*
  Meal Plan Generator
  CMSC 495 7381
  Group 5 - Joseph Awonusi, Jordan Bass, Daniel Beck, Zach Burke

  This class parses an input text file to import into a database and parses a database
  to export to a text file.  This allows for easy back-up and sharing of a database
  and gives the user a text version of the database to make edits outside the application.
*/

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public final class DatabaseParser {
	private MealDatabase mealDatabase;

	// Constructor that handles whether the user is trying to import or export
	public DatabaseParser(MealDatabase mealDatabase, boolean importFlag) {
		this.mealDatabase = mealDatabase;
		if (importFlag) {
			try {
				importDatabase();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null,
						"Error with database import! Ensure " + "input file is formatted correctly!", "Import Error",
						JOptionPane.ERROR_MESSAGE);
			}
		} else
			exportDatabase();
	}

	// Asks the user for a directory, exports the database to a text file with the
	// date/time prepended for easy identification
	private void exportDatabase() {
		JFileChooser fileChooser = new JFileChooser();
		File workingDirectory = new File(System.getProperty("user.dir"));
		fileChooser.setCurrentDirectory(workingDirectory);
		fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		fileChooser.setAcceptAllFileFilterUsed(false);
		File directoryForExport = null;
		if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
			directoryForExport = fileChooser.getSelectedFile();
		try {
			String fileName = new SimpleDateFormat("yyyy-MM-dd HHmmss").format(new Date()) + " Database Export.txt";
			Object[] allMeals = mealDatabase.getAllMealIDs();
			try (FileWriter fileWriter = new FileWriter(
					new File(directoryForExport.getAbsolutePath() + "/" + fileName))) {
				Object[] allMealProperties = mealDatabase.getEditableMealProperties();
				for (Object meal : allMeals) {
					for (Object property : allMealProperties) {
						fileWriter
								.write(property + ": " + mealDatabase.getMealProperty(meal + "", property + "") + "\n");
					}
					Object[] allIngredientProperties = mealDatabase.getEditableIngredientProperties(meal + "");
					Object[] allMealIngredients = mealDatabase.getMealIngredients(meal + "");
					for (Object ingredient : allMealIngredients) {
						fileWriter.write("INGREDIENT: ");
						for (Object property : allIngredientProperties) {
							fileWriter
									.write(mealDatabase.getIngredientProperty(meal + "", property + "", ingredient + "")
											+ " ");
						}
						fileWriter.write("\n");
					}
					fileWriter.write("\n");
				}
			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "FileWrite Error!", "IO Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	// Allows the user to select which file they want to import from
	private void importDatabase() {
		JFileChooser fileChooser = new JFileChooser();
		File workingDirectory = new File(System.getProperty("user.dir"));
		fileChooser.setCurrentDirectory(workingDirectory);
		File fileToImport = null;
		if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
			fileToImport = fileChooser.getSelectedFile();
		try {
			parseDatabase(fileToImport);
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Database Import Error! Ensure input " +
                    "file is properly formatted!", "IO Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	// Parses the text file for import into the existing database
	private void parseDatabase(File fileToParse) throws Exception {
		String name = "";
		int calories = 0;
		boolean favorite = false;
		boolean duplicate = false;
		String mealOfDay = "";
		ArrayList<Double> ingredientCounts = new ArrayList<>();
		ArrayList<String> ingredientMeasurements = new ArrayList<>();
		ArrayList<String> ingredients = new ArrayList<>();
        boolean success = true;
        
        try (Scanner fileScanner = new Scanner(fileToParse)) {
            while(fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                if(line.isEmpty() && success) {
                    double[] ingredientCount = ingredientCounts.stream().mapToDouble(Double::doubleValue).toArray();
                    String[] ingredientMeasurement = ingredientMeasurements.toArray(new String[0]);
                    String[] ingredient = ingredients.toArray(new String[0]);
                    mealDatabase.addMeal(name, calories, favorite, duplicate, mealOfDay, ingredientCount,
									ingredientMeasurement, ingredient);
                    name = "";
                    ingredientCounts.clear();
                    ingredientMeasurements.clear();
                    ingredients.clear();
                }
                else {
                    StringTokenizer tokenizer = new StringTokenizer(line);
                    while(tokenizer.hasMoreTokens()) {
                        String currentToken = tokenizer.nextToken();
                        if(currentToken.equalsIgnoreCase("name:")) {
                            while(tokenizer.hasMoreTokens()) {
                                name += tokenizer.nextToken().trim() + " ";
                            }
                        }
                        else if(currentToken.equalsIgnoreCase("calories:")) {
                            calories = Integer.parseInt(tokenizer.nextToken().trim() + "");
                        }
                        else if(currentToken.equalsIgnoreCase("favorite:")) {
                            favorite = Boolean.parseBoolean(tokenizer.nextToken().trim() + "");
                        }
                        else if(currentToken.equalsIgnoreCase("duplicate:")) {
                            duplicate = Boolean.parseBoolean(tokenizer.nextToken().trim() + "");
                        }
                        else if(currentToken.equalsIgnoreCase("meal_of_day:")) {
                            mealOfDay = tokenizer.nextToken().trim();
                        }
                        else if(currentToken.equalsIgnoreCase("ingredient:")) {
                            ingredientCounts.add(Double.parseDouble(tokenizer.nextToken()));
                            ingredientMeasurements.add(tokenizer.nextToken());
                            String ingredientName = "";
                            while(tokenizer.hasMoreTokens()) {
                                ingredientName += tokenizer.nextToken().trim() + " ";
                            }
                            ingredients.add(ingredientName);
                        }
                        else {
                            success = false;
                            throw new Exception();
                        }
                    }
                }
            }
        }
    }
}
