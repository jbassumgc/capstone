package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.text.JTextComponent;

import Database.MealDatabase;
import Utilities.TextPrompt;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;

class EnterAMealGUI extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final MealDatabase mealDatabase;
	private JTextField textFieldMealName;
	private JTextField textFieldCalories;
	private JCheckBox chckbxDinnerEAM;
	private JCheckBox chckbxLunchEAM;
	private JCheckBox chckbxBreakfastEAM;
	private JButton btnGeneratePlanEAM;
	private JButton btnCancelEAM;
	private JToggleButton tglbtnFavoriteEAM;
	private JToggleButton tglbtnAllowDuplicatesEAM;
    private JComboBox<Object> comboBoxIngredientCountEAM;
	private int ingredientCount;
    private final HomeScreenGUI home;

	EnterAMealGUI(MealDatabase mealDatabase, HomeScreenGUI home) {
		this.mealDatabase = mealDatabase;
        this.home = home;
		initGUI();
	}
	/**
	 * Create the panel.
	 */
	private void initGUI() {

		/***************************************************************
		 * Enter A Meal - Main
		 ****************************************************************/
		setBounds(0, 0, 400, 470);
		setBackground(Color.WHITE);
		setLayout(null);

		/***************************************************************
		 * Enter A Meal - Labels
		 ****************************************************************/
		JLabel txtTitleEAM = new JLabel("Enter A Meal");
		txtTitleEAM.setFont(new Font("Arial", Font.PLAIN, 18));
		txtTitleEAM.setBounds(148, 8, 103, 25);
		add(txtTitleEAM);
		
		/***************************************************************
		 * Enter A Meal - Meal Name Text field
		 ****************************************************************/
		textFieldMealName = new JTextField();
		addTextPrompt("Meal Name", textFieldMealName);
		textFieldMealName.setBounds(115, 44, 169, 20);
		add(textFieldMealName);
		textFieldMealName.setColumns(10);

		/***************************************************************
		 * Enter A Meal - Calories Text field
		 ****************************************************************/
		textFieldCalories = new JTextField();
		addTextPrompt("How Many Calories", textFieldCalories);
		textFieldCalories.setColumns(10);
		textFieldCalories.setBounds(115, 75, 169, 20);
		add(textFieldCalories);

		/***************************************************************
		 * Enter A Meal - Check boxes
		 ****************************************************************/
        ButtonGroup buttonMealGroup = new ButtonGroup();
		chckbxDinnerEAM = new JCheckBox("Dinner");
		chckbxDinnerEAM.setSelected(false);
		chckbxDinnerEAM.setBackground(Color.WHITE);
		chckbxDinnerEAM.setBounds(247, 102, 77, 23);
		buttonMealGroup.add(chckbxDinnerEAM);
        add(chckbxDinnerEAM);

		chckbxLunchEAM = new JCheckBox("Lunch");
		chckbxLunchEAM.setSelected(false);
		chckbxLunchEAM.setBackground(Color.WHITE);
		chckbxLunchEAM.setBounds(184, 102, 67, 23);
		buttonMealGroup.add(chckbxLunchEAM);
        add(chckbxLunchEAM);

		chckbxBreakfastEAM = new JCheckBox("Breakfast");
		chckbxBreakfastEAM.setSelected(true);
		chckbxBreakfastEAM.setBackground(Color.WHITE);
		chckbxBreakfastEAM.setBounds(98, 102, 82, 23);
		buttonMealGroup.add(chckbxBreakfastEAM);
        add(chckbxBreakfastEAM);
		
		/***************************************************************
		 * Enter A Meal - Toggle Favorites
		 ****************************************************************/
		tglbtnFavoriteEAM = new JCheckBox("Favorite");
        tglbtnFavoriteEAM.setSelected(false);
		tglbtnFavoriteEAM.setBackground(Color.WHITE);
		tglbtnFavoriteEAM.setBounds(98, 132, 82, 23);
		add(tglbtnFavoriteEAM);
		
		/***************************************************************
		 * Enter A Meal - Toggle Allow Duplicates
		 ****************************************************************/
		tglbtnAllowDuplicatesEAM = new JCheckBox("Allow Duplicates");
        tglbtnAllowDuplicatesEAM.setSelected(false);
		tglbtnAllowDuplicatesEAM.setBackground(Color.WHITE);
		tglbtnAllowDuplicatesEAM.setBounds(200, 132, 120, 23);
		add(tglbtnAllowDuplicatesEAM);
		
		/***************************************************************
		 * Enter A Meal - Ingredient count JComboBox
		 ****************************************************************/
        comboBoxIngredientCountEAM = new JComboBox<>();
        comboBoxIngredientCountEAM.setFont(new Font("Arial", Font.PLAIN, 12));
		comboBoxIngredientCountEAM.setBounds(127, 160, 145, 50);
		comboBoxIngredientCountEAM.setBorder(BorderFactory.createTitledBorder("Number of Ingredients"));
		comboBoxIngredientCountEAM.setBackground(Color.WHITE);
        for(int numbers = 1; numbers < 16; numbers++) {
            comboBoxIngredientCountEAM.addItem(numbers);
        }
        comboBoxIngredientCountEAM.setSelectedIndex(4);
		add(comboBoxIngredientCountEAM);
		
		/***************************************************************
		 * Enter A Meal - Enter A Meal Button
		 ****************************************************************/
		btnGeneratePlanEAM = new JButton("Add Ingredients");
		btnGeneratePlanEAM.setBounds(new Rectangle(0, 0, 10, 20));
		btnGeneratePlanEAM.setBounds(30, 231, 140, 30);
		add(btnGeneratePlanEAM);
		btnGeneratePlanEAM.addActionListener(event -> {
			try {
                String mealName = textFieldMealName.getText().trim();
                if(mealName.isEmpty())
                    throw new Exception();
                
                int calorieCount = Integer.parseInt(textFieldCalories.getText().trim());
                if(calorieCount < 0)
                    throw new Exception();
                
                boolean favoriteFlag = false;
                if(tglbtnFavoriteEAM.isSelected())
                    favoriteFlag = true;
                
                boolean duplicateFlag = false;
                if(tglbtnAllowDuplicatesEAM.isSelected())
                    duplicateFlag = true;
                
                String mealOfDay;
                if(chckbxBreakfastEAM.isSelected())
                    mealOfDay = "Breakfast";
                else if(chckbxLunchEAM.isSelected())
                    mealOfDay = "Lunch";
                else
                    mealOfDay = "Dinner";
                
                ingredientCount = Integer.parseInt(comboBoxIngredientCountEAM.getSelectedItem() + "");
				pageFlip(new IngredientGUI(mealDatabase, ingredientCount, 
                        mealName, calorieCount, favoriteFlag, duplicateFlag, 
                        mealOfDay, home));
				// add error handling for how many ingredients can fit on screen
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Error in Generate Plan Execute button!");
			}
		});

		/***************************************************************
		 * Enter A Meal - Cancel Button
		 ****************************************************************/
		btnCancelEAM = new JButton("Cancel");
		btnCancelEAM.setBounds(new Rectangle(0, 0, 10, 20));
		btnCancelEAM.setBounds(220, 231, 140, 30);
		add(btnCancelEAM);
		btnCancelEAM.addActionListener(event -> {
			try {
				removeAll();
				home.cancelPress();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Error in cancel button!");
			}
		});
	}
	
	private void addTextPrompt(String display, JTextComponent component) {
		TextPrompt tpi = new TextPrompt(display, component);
		tpi.changeStyle(Font.BOLD + Font.ITALIC);
		tpi.setForeground(Color.LIGHT_GRAY);
	}
	
	public int getIngredientCount() {
		return this.ingredientCount;
	}
	
	private void pageFlip(JPanel newPage) {
		this.removeAll();
		this.add(newPage);
		this.validate();
		this.repaint();
	}
}
