package Backend;

/*
  Meal Plan Generator
  CMSC 495 7381
  Group 5 - Joseph Awonusi, Jordan Bass, Daniel Beck, Zach Burke

  This class holds the meal plan for display
*/

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.JOptionPane;

import Database.MealDatabase;
import com.itextpdf.text.BaseColor;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Paragraph;
import java.util.List;

public class MealPlan {
	MealDatabase mealDatabase;
	boolean[] mealsIncluded;
    boolean[] outputOptions;
	int daysOfMeals;
	ArrayList<String> selectedMeals = new ArrayList<>();
	ArrayList<String> selectedMealIngredients;
	List<String> selectedMealIngredientMeasurements;
	List<String> selectedMealIngredientAmounts;
	int duplicatePeriod;
    String selectedDayOfWeek;
    int daysPerList;

	// Constructor that establishes the options and number of meals and duplication
	// period
	public MealPlan(MealDatabase mealDatabase, boolean[] mealsIncluded, boolean[] outputOptions,
            int daysOfMeals, int duplicatePeriod, String selectedDayOfWeek, int daysPerList) {
		this.mealDatabase = mealDatabase;
		this.mealsIncluded = mealsIncluded;
        this.outputOptions = outputOptions;
		this.daysOfMeals = daysOfMeals;
		this.duplicatePeriod = duplicatePeriod;
        this.selectedDayOfWeek = selectedDayOfWeek;
        this.daysPerList = daysPerList;
	}

	// Creates random numbers and requests a random meal from the meal database
	public void generatePlan() {
        int mealsPerDay = 0;
        int listDelineation = 0;
        if(mealsIncluded[0])
            listDelineation++;
        if(mealsIncluded[1])
            listDelineation++;
        if(mealsIncluded[2])
            listDelineation++;
        listDelineation *= daysPerList;
        
		if ((mealsIncluded[0] || mealsIncluded[1] || mealsIncluded[2]) &&
                (outputOptions[0] || mealsIncluded[1] || mealsIncluded[2])) {
			mealDatabase.buildMealArrays();
            for(int counter = 0; counter < daysOfMeals; counter++) {
                if(duplicatePeriod > 0) {
                  if((counter + 1) % duplicatePeriod == 0 && duplicatePeriod > 0)
                            mealDatabase.rebuildMealArrays();
                }
                mealsPerDay = 0;
                if(mealsIncluded[0]) {
                        int randomNumber = ThreadLocalRandom.current().nextInt(0, mealDatabase.breakfastMeals.size());
                        selectedMeals.add(mealDatabase.getRandomMeal(1, randomNumber));
                        mealsPerDay++;
                    }
                    if (mealsIncluded[1]) {
                        int randomNumber = ThreadLocalRandom.current().nextInt(0, mealDatabase.lunchMeals.size());
                        selectedMeals.add(mealDatabase.getRandomMeal(2, randomNumber));
                        mealsPerDay++;
                    }
                    if (mealsIncluded[2]) {
                        int randomNumber = ThreadLocalRandom.current().nextInt(0, mealDatabase.dinnerMeals.size());
                        selectedMeals.add(mealDatabase.getRandomMeal(3, randomNumber));
                        mealsPerDay++;
                    }
                }

			// Displays the meal plan
			int day = 1;
			String displayMealPlan = "";
			int selectedMealCounter = 0;
            String[] dayOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
            int dayOfWeekCounter;
            switch(selectedDayOfWeek) {
                case "Monday":
                    dayOfWeekCounter = 1;
                    break;
                case "Tuesday":
                    dayOfWeekCounter = 2;
                    break;
                case "Wednesday":
                    dayOfWeekCounter = 3;
                    break;
                case "Thursday":
                    dayOfWeekCounter = 4;
                    break;
                case "Friday":
                    dayOfWeekCounter = 5;
                    break;
                case "Saturday":
                    dayOfWeekCounter = 6;
                    break;
                default:
                    dayOfWeekCounter = 0;
                    break;
            }
			while (selectedMealCounter < selectedMeals.size()) {
				displayMealPlan += "\nDay " + day + " - " + dayOfWeek[dayOfWeekCounter % 7] + "\n    ";
				if (mealsIncluded[0]) {
					displayMealPlan += "Breakfast - " + mealDatabase.getMealName(selectedMeals.get(selectedMealCounter))
							+ "\n    ";
					selectedMealCounter++;
				}
				if (mealsIncluded[1]) {
					displayMealPlan += "Lunch - " + mealDatabase.getMealName(selectedMeals.get(selectedMealCounter))
							+ "\n    ";
					selectedMealCounter++;
				}
				if (mealsIncluded[2]) {
					displayMealPlan += "Dinner - " + mealDatabase.getMealName(selectedMeals.get(selectedMealCounter))
							+ "\n    ";
					selectedMealCounter++;
				}
                dayOfWeekCounter++;
				day++;
			}
            
            ArrayList<String> combinedShoppingList = new ArrayList<>();
            for(int delineationCounter = 0; delineationCounter < selectedMeals.size(); delineationCounter += listDelineation) { 
                int endDay = delineationCounter + listDelineation;
                int daysDisplay = 1;
                if(selectedMeals.size() > endDay) {
                    selectedMealIngredients = mealDatabase.getIngredients(selectedMeals.subList(delineationCounter, endDay));
                    selectedMealIngredientMeasurements = mealDatabase.getIngredientMeasurements(selectedMeals.subList(delineationCounter, endDay));
                    selectedMealIngredientAmounts = mealDatabase.getIngredientAmounts(selectedMeals.subList(delineationCounter, endDay));
                }
                else {
                    endDay = selectedMeals.size();
                    selectedMealIngredients = mealDatabase.getIngredients(selectedMeals.subList(delineationCounter, endDay));
                    selectedMealIngredientMeasurements = mealDatabase.getIngredientMeasurements(selectedMeals.subList(delineationCounter, endDay));
                    selectedMealIngredientAmounts = mealDatabase.getIngredientAmounts(selectedMeals.subList(delineationCounter, endDay));
                }
                ArrayList<String> combinedShoppingListDelineated = getShoppingList(selectedMealIngredients);
                combinedShoppingList.add("\nList " + (delineationCounter / listDelineation + 1) + 
                        " (Days " + (delineationCounter / mealsPerDay + 1) + " through " + (endDay / mealsPerDay) +  "):"); 
                for(String listItem : combinedShoppingListDelineated)
                    combinedShoppingList.add("    " + listItem);
                daysDisplay += daysPerList;
            }
			// Displays the shopping list
			String displayGroceryList = "\n";
			for (int counter = 0; counter < combinedShoppingList.size(); counter++) {
				displayGroceryList += combinedShoppingList.get(counter) + "\n";
			}
            if(outputOptions[0]) {
                String fileName = "";
                try { 
                    JFileChooser outputFile = new JFileChooser();
                    File workingDirectory = new File(System.getProperty("user.dir"));
                    outputFile.setSelectedFile(new File(new SimpleDateFormat("yyyy-MM-dd HHmmss").format(new Date()) + " Meal Plan.txt"));
                    outputFile.setCurrentDirectory(workingDirectory);
                    outputFile.setFileFilter(new FileNameExtensionFilter("txt file","txt"));
                    int returnVal = outputFile.showSaveDialog(null);
                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        File file = outputFile.getSelectedFile();
                        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                            writer.write("Meal Plan:\n" + displayMealPlan);
                            writer.write("\n\nGrocery List:" + displayGroceryList);
                        }
                        fileName = file.getName();
                        
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error writing to file "
                    + fileName, "IO Error", JOptionPane.ERROR_MESSAGE);
                } 
            }
            if(outputOptions[1]) {
                JOptionPane.showMessageDialog(null, displayMealPlan, "Meal Plan", JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showMessageDialog(null, displayGroceryList, "Grocery List", JOptionPane.INFORMATION_MESSAGE);
            }
            
            
            if(outputOptions[2]) {
                String fileName = "";
                try {
                    JFileChooser outputFile = new JFileChooser();
                    File workingDirectory = new File(System.getProperty("user.dir"));
                    outputFile.setSelectedFile(new File(new SimpleDateFormat("yyyy-MM-dd HHmmss").format(new Date()) + " Meal Plan.pdf"));
                    outputFile.setCurrentDirectory(workingDirectory);
                    outputFile.setFileFilter(new FileNameExtensionFilter("pdf file","pdf"));
                    int returnVal = outputFile.showSaveDialog(null);
                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        File file = outputFile.getSelectedFile();
                        Document document = new Document();
                        PdfWriter.getInstance(document, new FileOutputStream(file));
                        document.open();
                        Paragraph planTitle = new Paragraph("Meal Plan", FontFactory.getFont(FontFactory.COURIER, 18, BaseColor.BLACK));
                        planTitle.setAlignment(Element.ALIGN_CENTER);
                        document.add(planTitle);
                        
                        Paragraph mealPlan = new Paragraph(displayMealPlan, FontFactory.getFont(FontFactory.COURIER, 12, BaseColor.BLACK));
                        document.add(mealPlan);
                        
                        document.newPage();
                        
                        Paragraph groceryTitle = new Paragraph("Grocery List", FontFactory.getFont(FontFactory.COURIER, 18, BaseColor.BLACK));
                        groceryTitle.setAlignment(Element.ALIGN_CENTER);
                        document.add(groceryTitle);
                        
                        Paragraph groceryList = new Paragraph(displayGroceryList, FontFactory.getFont(FontFactory.COURIER, 12, BaseColor.BLACK));
                        document.add(groceryList);
                        
                        document.close();
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error writing to file "
                    + fileName, "IO Error", JOptionPane.ERROR_MESSAGE);
                }
            }
			mealDatabase.resetMealPlan();
		} else
			JOptionPane.showMessageDialog(null, "You must select at least one meal of the day option"
                    + " and at least one output option!", "IO Error",
					JOptionPane.ERROR_MESSAGE);
	}

	// Combines duplicate ingredients with like measurements
	public ArrayList<String> getShoppingList(ArrayList<String> ingredientList) {
		ArrayList<String> combinedShoppingList = new ArrayList<>();
		ArrayList<String> tempList = new ArrayList<>();
		DecimalFormat format = new DecimalFormat("#,###.###");
		for (int countX = 0; countX < ingredientList.size(); countX++) {
			double totalIngredientCount = Double.parseDouble(selectedMealIngredientAmounts.get(countX));
			for (int countY = countX + 1; countY < ingredientList.size(); countY++) {
				if (ingredientList.get(countX).equals(ingredientList.get(countY))) {
					if (selectedMealIngredientMeasurements.get(countX)
							.equals(selectedMealIngredientMeasurements.get(countY))) {
						totalIngredientCount += Double.parseDouble(selectedMealIngredientAmounts.get(countY));
					}
				}
			}
			if (!tempList.contains(ingredientList.get(countX))) {
				tempList.add(ingredientList.get(countX));
				combinedShoppingList.add(format.format(totalIngredientCount) + " "
						+ selectedMealIngredientMeasurements.get(countX) + " " + ingredientList.get(countX));
			}
		}
		return combinedShoppingList;
	}
}
