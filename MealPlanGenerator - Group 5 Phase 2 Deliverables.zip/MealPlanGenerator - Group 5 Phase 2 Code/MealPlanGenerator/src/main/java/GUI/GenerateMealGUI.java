package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import Backend.MealPlan;
import Database.MealDatabase;

public class GenerateMealGUI extends JPanel {

	private static final long serialVersionUID = 1L;
	MealDatabase mealDatabase;
    HomeScreenGUI home;

	/**
	 * Create the panel.
	 */
	public GenerateMealGUI(MealDatabase mealDatabase, HomeScreenGUI home) {
		this.mealDatabase = mealDatabase;
        this.home = home;
		initGUI();
	}
	
	public void initGUI() {
		/***************************************************************
		 * Generate Meal Plan - Main
		 ****************************************************************/
//		pnlGenerateMealPlan = new JPanel();
		setBounds(0, 0, 400, 470);
		setBackground(Color.WHITE);
		setLayout(null);

		/***************************************************************
		 * Generate Meal Plan - Day to start Selector
		 ****************************************************************/
		String[] days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		JComboBox dropdownDaySelector = new JComboBox(days);

		dropdownDaySelector.setBackground(Color.WHITE);
		dropdownDaySelector.setBorder(new TitledBorder(
				new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)),
				"Day To Start", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		dropdownDaySelector.setFont(new Font("Arial", Font.PLAIN, 12));
		dropdownDaySelector.setEditable(false);
		dropdownDaySelector.setBounds(90, 67, 220, 50);
		dropdownDaySelector.setSelectedIndex(0);
		add(dropdownDaySelector);
        
        JComboBox comboBoxDaysPerPlan = new JComboBox();
		comboBoxDaysPerPlan.setFont(new Font("Arial", Font.PLAIN, 12));
		comboBoxDaysPerPlan.setBounds(137, 207, 125, 50);
		comboBoxDaysPerPlan.setBorder(BorderFactory.createTitledBorder("Meal Plan Duration"));
		comboBoxDaysPerPlan.setBackground(Color.WHITE);
        for(int numbers = 1; numbers < 61; numbers++) {
            comboBoxDaysPerPlan.addItem(numbers);
        }
        comboBoxDaysPerPlan.setSelectedIndex(6);
		add(comboBoxDaysPerPlan);
        
        JComboBox comboBoxDuplicateDays = new JComboBox();
		comboBoxDuplicateDays.setFont(new Font("Arial", Font.PLAIN, 12));
		comboBoxDuplicateDays.setBounds(105, 276, 190, 50);
		comboBoxDuplicateDays.setBorder(BorderFactory.createTitledBorder("Allow Duplicates Every _ Days"));
		comboBoxDuplicateDays.setBackground(Color.WHITE);
        for(int numbers = 0; numbers < 61; numbers++) {
            comboBoxDuplicateDays.addItem(numbers);
        }
        comboBoxDuplicateDays.setSelectedIndex(0);
		add(comboBoxDuplicateDays);
        
		JSlider sliderDaysToGenerate = new JSlider(SwingConstants.HORIZONTAL, 1, 15, 7);
		sliderDaysToGenerate.setPaintTicks(true);
		sliderDaysToGenerate.setPaintLabels(true);
		sliderDaysToGenerate.setMinorTickSpacing(1);
		sliderDaysToGenerate.setMajorTickSpacing(1);
		sliderDaysToGenerate.setFont(new Font("Arial", Font.PLAIN, 12));
		sliderDaysToGenerate.setBorder(BorderFactory.createTitledBorder("Days Per Grocery List"));
		sliderDaysToGenerate.setBackground(Color.WHITE);
		sliderDaysToGenerate.setBounds(47, 128, 306, 68);
		add(sliderDaysToGenerate);

		/***************************************************************
		 * Generate Meal Plan - Check boxes
		 ****************************************************************/
		JCheckBox chckbxBreakfast = new JCheckBox("Breakfast");
		chckbxBreakfast.setSelected(true);
		chckbxBreakfast.setBackground(Color.WHITE);
		chckbxBreakfast.setBounds(90, 37, 82, 23);
		add(chckbxBreakfast);

		JCheckBox chckbxLunch = new JCheckBox("Lunch");
		chckbxLunch.setSelected(true);
		chckbxLunch.setBackground(Color.WHITE);
		chckbxLunch.setBounds(174, 37, 77, 23);
		add(chckbxLunch);

		JCheckBox chckbxDinner = new JCheckBox("Dinner");
		chckbxDinner.setSelected(true);
		chckbxDinner.setBackground(Color.WHITE);
		chckbxDinner.setBounds(253, 37, 77, 23);
		add(chckbxDinner);
        
        JCheckBox chckbxTextOutput = new JCheckBox("Output to Text");
		chckbxTextOutput.setSelected(false);
		chckbxTextOutput.setBackground(Color.WHITE);
		chckbxTextOutput.setBounds(25, 360, 110, 23);
		add(chckbxTextOutput);
        
        JCheckBox chckbxJPaneOutput = new JCheckBox("Output to Screen");
		chckbxJPaneOutput.setSelected(true);
		chckbxJPaneOutput.setBackground(Color.WHITE);
		chckbxJPaneOutput.setBounds(140, 360, 125, 23);
		add(chckbxJPaneOutput);
        
        JCheckBox chckbxPDFOutput = new JCheckBox("Output to PDF");
		chckbxPDFOutput.setSelected(false);
		chckbxPDFOutput.setBackground(Color.WHITE);
		chckbxPDFOutput.setBounds(275, 360, 120, 23);
		add(chckbxPDFOutput);

		/***************************************************************
		 * Generate Meal Plan - Generate Plan Button
		 ****************************************************************/
		JButton btnGeneratePlan = new JButton("Generate Plan");
		btnGeneratePlan.setBounds(new Rectangle(0, 0, 10, 20));
		btnGeneratePlan.setBounds(47, 400, 140, 30);
		add(btnGeneratePlan);
		btnGeneratePlan.addActionListener(event -> {
			try {
                boolean[] mealOptions = new boolean[3];
                boolean[] outputOptions = new boolean[3];
                if(chckbxBreakfast.isSelected())
                    mealOptions[0] = true;
                if(chckbxLunch.isSelected())
                    mealOptions[1] = true;
                if(chckbxDinner.isSelected())
                    mealOptions[2] = true;
                if(chckbxTextOutput.isSelected())
                    outputOptions[0] = true;
                if(chckbxJPaneOutput.isSelected())
                    outputOptions[1] = true;
                if(chckbxPDFOutput.isSelected())
                    outputOptions[2] = true;
                int numberMeals = Integer.parseInt(comboBoxDaysPerPlan.getSelectedItem() + "");
                int duplicateDuration = Integer.parseInt(comboBoxDuplicateDays.getSelectedItem() + "");
                String dayOfWeek = dropdownDaySelector.getSelectedItem() + "";
                int daysPerList = sliderDaysToGenerate.getValue();
                
				MealPlan mealPlan = new MealPlan(mealDatabase, mealOptions, 
                        outputOptions, numberMeals, duplicateDuration, dayOfWeek, daysPerList);
                mealPlan.generatePlan();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
					"Incorrect number of meals for parameters! "
							+ "Please try again with a larger database, more duplicate meals, or smaller"
							+ " duplicate meal window!",
					"Incorrect Number Of Meals Error", JOptionPane.ERROR_MESSAGE);
            }
		});
		
		/***************************************************************
		 * Generate Meal Plan - Cancel Button
		 ****************************************************************/
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(new Rectangle(0, 0, 10, 20));
		btnCancel.setBounds(213, 400, 140, 30);
		add(btnCancel);
		btnCancel.addActionListener(event -> {
			try {
                removeAll();
				home.cancelPress();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Error in cancel button!");
			}
		});

		/***************************************************************
		 * Generate Meal Plan - Labels
		 ****************************************************************/
		JLabel txtTitle = new JLabel("Meal Generation Settings");
		txtTitle.setFont(new Font("Arial", Font.PLAIN, 18));
		txtTitle.setBounds(98, 8, 203, 25);
		add(txtTitle);
	}

}
