package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;
import java.awt.Rectangle;
import javax.swing.JComponent;
import javax.swing.JOptionPane;

import Backend.MealDataRow;
import Database.MealDatabase;
import Utilities.TextPrompt;

public final class IngredientGUI extends JPanel {

	private static final long serialVersionUID = 1L;
	int ingredientCount;
	MealDatabase mealDatabase;
	String mealName;
	int calorieCount;
	boolean favoriteFlag;
	boolean duplicateFlag;
	String mealOfDay;
	MealDataRow[] dataRows;
	double[] ingredientCounts;
	String[] ingredientMeasurements;
	String[] ingredients;
    HomeScreenGUI home;
    Boolean addSuccess;

	/**
	 * Create the panel.
	 */
	public IngredientGUI(MealDatabase mealDatabase, int ingredientCount, 
            String mealName, int calorieCount, boolean favoriteFlag, 
            boolean duplicateFlag, String mealOfDay, HomeScreenGUI home) {
		this.ingredientCount = ingredientCount;
		this.mealDatabase = mealDatabase;
        this.calorieCount = calorieCount;
        this.duplicateFlag = duplicateFlag;
        this.favoriteFlag = favoriteFlag;
        this.mealName = mealName;
        this.mealOfDay = mealOfDay;
        this.home = home;
        addSuccess = false;
		initGUI();
	}

	public void initGUI() {
		setBackground(Color.WHITE);
		setBounds(0, 0, 400, 470);
		setBorder(new EmptyBorder(10, 20, 10, 20));

		// Creates new MealDataRows for each ingredient
		dataRows = new MealDataRow[ingredientCount];
        int spacing = 36;
        for(int spacingCount = 5; spacingCount < ingredientCount; spacingCount++)
            spacing--;
		for (int counter = 0; counter < ingredientCount; counter++) {
			dataRows[counter] = new MealDataRow(28 + (spacing * counter));
		}
		ingredientCounts = new double[ingredientCount];
		ingredientMeasurements = new String[ingredientCount];
		ingredients = new String[ingredientCount];
        
		JLabel ingredientAmountLabel = new JLabel("Amount");
		ingredientAmountLabel.setBounds(20, 5, 65, 20);
		ingredientAmountLabel.setHorizontalAlignment(JLabel.CENTER);
        
		JLabel ingredientMeasurementLabel = new JLabel("Measurement");
		ingredientMeasurementLabel.setBounds(95, 5, 83, 20);
		ingredientMeasurementLabel.setHorizontalAlignment(JLabel.CENTER);
        
		JLabel ingredientLabel = new JLabel("Name (Singular Form)");
		ingredientLabel.setBounds(188, 5, 202, 20);
		ingredientLabel.setHorizontalAlignment(JLabel.CENTER);

        setLayout(null);
        add(ingredientAmountLabel);
		add(ingredientMeasurementLabel);
		add(ingredientLabel);
        
		for (MealDataRow dataRow : dataRows) {
            addTextPrompt("3", dataRow.getColumn(0));
            addTextPrompt("Apple", dataRow.getColumn(2));
			add(dataRow.getColumn(0));
			add(dataRow.getColumn(1));
			add(dataRow.getColumn(2));
		}

		// Calls addMeal() method on button press
		JButton addMealButton = new JButton("Add Meal");
        addMealButton.setBounds(new Rectangle(0, 0, 10, 20));
		addMealButton.setBounds(40, 420, 140, 30);
		add(addMealButton);
		addMealButton.addActionListener((ActionEvent e) -> {
            addMeal();
            if(addSuccess) {
                removeAll();
                home.cancelPress();
            }
		});

		/***************************************************************
		 * Enter A Meal - Cancel Button
		 ****************************************************************/
		JButton btnCancelEAM = new JButton("Cancel");
		btnCancelEAM.setBounds(new Rectangle(0, 0, 10, 20));
		btnCancelEAM.setBounds(200, 420, 140, 30);
		add(btnCancelEAM);
		btnCancelEAM.addActionListener(event -> {
			try {
				removeAll();
				home.cancelPress();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Error in cancel button!");
			}
		});
	}
	
	public void addTextPrompt(String display, JComponent component) {
		TextPrompt tp = new TextPrompt(display, (JTextComponent) component);
		tp.changeStyle(Font.BOLD + Font.ITALIC);
		tp.setForeground(Color.LIGHT_GRAY);
	}
    
    public void addMeal() {
        int ingredientNumber = 0;
        try {
            for(MealDataRow dataRow : dataRows){
                if(Double.parseDouble(dataRow.getData(0)) < 0)
                    throw new Exception();
                if(dataRow.getData(2).trim().isEmpty())
                    throw new Exception();
                addSuccess = true;
            }
        } catch(Exception e) {
            addSuccess = false;
            JOptionPane.showMessageDialog(null, "Ingredient amounts must be positive numbers"
                    + " and have a name!", "IO Error", JOptionPane.ERROR_MESSAGE);
        }
            
        if(addSuccess) {
            for(MealDataRow dataRow : dataRows) {
                ingredientCounts[ingredientNumber] = Double.parseDouble(dataRow.getData(0));
                ingredientMeasurements[ingredientNumber] = dataRow.getData(1);
                ingredients[ingredientNumber] = dataRow.getData(2);
                ingredientNumber++;
                dataRow.reset();
            }
            mealDatabase.addMeal(mealName, calorieCount, favoriteFlag, duplicateFlag, mealOfDay, ingredientCounts, ingredientMeasurements, ingredients);
            JOptionPane.showMessageDialog(null, "Meal successfully entered!", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
