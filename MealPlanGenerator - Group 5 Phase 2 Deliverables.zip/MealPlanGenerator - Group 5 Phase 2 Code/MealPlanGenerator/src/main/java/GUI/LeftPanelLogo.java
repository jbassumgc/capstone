package GUI;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Utilities.RandomNumber;

public class LeftPanelLogo extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public LeftPanelLogo() {
		initGUI();
	}
	
	public void initGUI() {
		/***************************************************************
		 * Left Panel - Logo
		 ****************************************************************/
		setBounds(0, 0, 400, 471);
		setBackground(Color.WHITE);
		setLayout(null);

		/***************************************************************
		 * Left Panel - Logo Picker and Placement
		 ****************************************************************/
		// Dan playing around with random logo selection
		RandomNumber logoPicker = new RandomNumber(3); // how many logos are in the classes folder?
		int logoPicked = logoPicker.getNewNum();
		JLabel picLabel = new JLabel(
				// add .getNewNum here when figured out. Also add or remove the "%d" after logo
				new ImageIcon(
						System.getProperty("user.dir") + String.format("\\classes\\logos\\logo%d.png", logoPicked)));
		picLabel.setBounds(0, 0, 392, 471);
		add(picLabel);
	}
}
