package GUI;

import Backend.MealDataRow;
import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Database.MealDatabase;
import Utilities.TextPrompt;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

public class EditAMealGUI extends JPanel {

	private static final long serialVersionUID = 1L;
	MealDatabase mealDatabase;
    HomeScreenGUI home;
    JComboBox selectAMeal;
    JComboBox selectAMealProperty;
    JTextField editAMealProperty;
    JComboBox selectAnIngredientProperty;
    JTextField editAnIngredientProperty;
    JComboBox selectAnIngredient;
    JButton changeMealProperty;
    JButton changeIngredientProperty;
    String selectedMeal;
    String selectedMealID;
    String selectedMealName;
    MealDataRow dataRow;
    JButton deleteIngredientButton;
    JButton editIngredientButton;
    JButton addIngredientButton;
    JLabel ingredientAmountLabel;
    JLabel ingredientMeasurementLabel;
    JLabel ingredientLabel;
    JButton addIngredient;
    boolean addSuccess;
	/**
	 * Create the panel.
	 */
	public EditAMealGUI(MealDatabase mealDatabase, HomeScreenGUI home) {
		this.mealDatabase = mealDatabase;
        this.home = home;
        addSuccess = false;
		initGUI();
	}
	
	public void initGUI() {
		/***************************************************************
		 * Edit A Meal - Main
		 ****************************************************************/
		setBounds(0, 0, 400, 470);
		setBackground(Color.WHITE);
		setLayout(null);

		/***************************************************************
		 * Edit A Meal - Select A Meal
		 ****************************************************************/
        selectAMeal = new JComboBox(mealDatabase.getAllMeals());
		selectAMeal.setFont(new Font("Arial", Font.PLAIN, 12));
		selectAMeal.setBounds(50, 40, 300, 50);
		selectAMeal.setBorder(BorderFactory.createTitledBorder("Select a Meal to Edit"));
		selectAMeal.setBackground(Color.WHITE);
        selectAMeal.setSelectedIndex(0);
		add(selectAMeal);
        
        selectedMeal = selectAMeal.getSelectedItem() + "";
        selectedMealID = selectedMeal.substring(selectedMeal.lastIndexOf(' ') + 1);
        selectedMealName = mealDatabase.getMealName(selectedMealID);
        selectAMeal.addActionListener(event -> {
            updateSelectedMeal(selectAMeal.getSelectedItem() + "");
		});
        
        /***************************************************************
		 * Edit A Meal - Edit Meal Properties
		 ****************************************************************/
		JButton btnEditMealProperties = new JButton("Edit Meal Properties");
		btnEditMealProperties.setBounds(new Rectangle(0, 0, 10, 20));
		btnEditMealProperties.setBounds(10, 120, 170, 30);
		add(btnEditMealProperties);
		btnEditMealProperties.addActionListener(event -> {
            showEditPropertyFields();

		});
        
        /***************************************************************
		 * Edit A Meal - Edit Meal Ingredients
		 ****************************************************************/
		JButton btnEditMealIngredients = new JButton("Edit Meal Ingredients");
		btnEditMealIngredients.setBounds(new Rectangle(0, 0, 10, 20));
		btnEditMealIngredients.setBounds(220, 120, 170, 30);
		add(btnEditMealIngredients);
		btnEditMealIngredients.addActionListener(event -> {
            showEditIngredientFields();

		});
        
        /***************************************************************
		 * Edit A Meal - Delete Meal
		 ****************************************************************/
		JButton btnDeleteMeal = new JButton("Delete Meal");
		btnDeleteMeal.setBounds(new Rectangle(0, 0, 10, 20));
		btnDeleteMeal.setBounds(140, 173, 120, 30);
		add(btnDeleteMeal);
		btnDeleteMeal.addActionListener(event -> {
            if (JOptionPane.showConfirmDialog(null, "Are you sure you want"
                    + " to delete " + selectedMealName + "?", "Confirm Delete" , 
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                mealDatabase.deleteMeal(selectedMealID);
                JOptionPane.showMessageDialog(null, selectedMealName + " successfully deleted!");
                removeAll();
				home.cancelPress();
            } 
		});
        
        selectAnIngredient = new JComboBox();
        selectAMealProperty = new JComboBox();        
        editAMealProperty = new JTextField();
        selectAnIngredientProperty = new JComboBox();        
        editAnIngredientProperty = new JTextField();
        changeMealProperty = new JButton();
        changeIngredientProperty = new JButton();
        deleteIngredientButton = new JButton();
        editIngredientButton = new JButton();
        addIngredientButton = new JButton();
        addIngredient = new JButton();
        ingredientLabel = new JLabel();
        ingredientAmountLabel = new JLabel();
        ingredientMeasurementLabel = new JLabel();
        dataRow = new MealDataRow(340);
      
		/***************************************************************
		 * Edit A Meal - Cancel Button
		 ****************************************************************/
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(new Rectangle(0, 0, 10, 20));
		btnCancel.setBounds(130, 400, 140, 30);
		add(btnCancel);
		btnCancel.addActionListener(event -> {
			try {
                removeAll();
				home.cancelPress();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Error in cancel button!");
			}
		});

		/***************************************************************
		 * Edit A Meal - Labels
		 ****************************************************************/
		JLabel txtTitle = new JLabel("Edit A Meal");
		txtTitle.setFont(new Font("Arial", Font.PLAIN, 18));
		txtTitle.setBounds(151, 8, 97, 25);
		add(txtTitle);
	}
    
    void showEditPropertyFields() {
        updateSelectedMeal(selectedMeal);
        selectAMealProperty = new JComboBox(mealDatabase.getEditableMealProperties());
		selectAMealProperty.setFont(new Font("Arial", Font.PLAIN, 12));
		selectAMealProperty.setBounds(30, 190, 200, 60);
		selectAMealProperty.setBorder(BorderFactory.createTitledBorder("Select a Meal Property to Edit"));
		selectAMealProperty.setBackground(Color.WHITE);
        selectAMealProperty.addItem("-");
        selectAMealProperty.setSelectedItem("-");
        add(selectAMealProperty);
        selectAMealProperty.addActionListener(event -> {
            String selectedProperty = selectAMealProperty.getSelectedItem() + "";
            if(!selectedProperty.equals("-")) 
                editMealPropertyField(selectedProperty);
		});
        validate();
        repaint();
    }
    
    void editMealPropertyField(String selectedProperty) {
        remove(editAMealProperty);
        editAMealProperty = new JTextField();
        editAMealProperty.setBounds(30, 260, 210, 30);
        editAMealProperty.setBackground(Color.WHITE);
        addTextPrompt("Current Value: " + mealDatabase.getPropertyValue(selectedMealID, selectedProperty), editAMealProperty);
        add(editAMealProperty);
        
        remove(changeMealProperty);
        changeMealProperty = new JButton("Commit Change");
        changeMealProperty.setBounds(new Rectangle(0, 0, 10, 20));
		changeMealProperty.setBounds(250, 260, 130, 30);
		add(changeMealProperty);
        validate();
        repaint();
        
		changeMealProperty.addActionListener(event -> {
			String newProperty = editAMealProperty.getText().trim();
            try {
                if(selectedProperty.equalsIgnoreCase("duplicate") || 
                        selectedProperty.equalsIgnoreCase("favorite")) {
                    if(!newProperty.equalsIgnoreCase("true") &&
                            !newProperty.equalsIgnoreCase("false")) {
                        throw new Exception();
                    }
                }
                else if(selectedProperty.equalsIgnoreCase("calories")) 
                    Double.parseDouble(newProperty);
                else if(selectedProperty.equalsIgnoreCase("meal_of_day")) {
                    if(!newProperty.equalsIgnoreCase("breakfast") &&
                            !newProperty.equalsIgnoreCase("lunch") &&
                            !newProperty.equalsIgnoreCase("dinner"))
                        throw new Exception();
                }
                    
                if (JOptionPane.showConfirmDialog(null, "Are you sure you want"
                        + " to change " + selectedMealName + "'s " + 
                        selectedProperty.toLowerCase() + " property to " + newProperty + "?", 
                        "Confirm Change" , JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    mealDatabase.editMealProperty(selectedMealID, selectedProperty, newProperty);
                    JOptionPane.showMessageDialog(null, selectedMealName + " successfully changed!");
                    removeAll();
                    home.cancelPress();
                }
            } catch(Exception e) {
                JOptionPane.showMessageDialog(null, newProperty + " is an incorrect format for " +
                       selectedProperty + "! " + selectedMealName + " unsuccessfully changed!");
            }
        });
    }
    
    public void addTextPrompt(String display, JComponent component) {
		TextPrompt tp = new TextPrompt(display, (JTextComponent) component);
		tp.changeStyle(Font.BOLD + Font.ITALIC);
		tp.setForeground(Color.LIGHT_GRAY);
	}
    
    void showEditIngredientFields() {   
        updateSelectedMeal(selectedMeal);
        selectAnIngredient = new JComboBox(mealDatabase.getMealIngredients(selectedMealID));
		selectAnIngredient.setFont(new Font("Arial", Font.PLAIN, 12));
		selectAnIngredient.setBounds(30, 190, 210, 60);
		selectAnIngredient.setBorder(BorderFactory.createTitledBorder("Select Ingredient to Edit"));
		selectAnIngredient.setBackground(Color.WHITE);
        selectAnIngredient.setSelectedIndex(0);
        add(selectAnIngredient);
        
        deleteIngredientButton = new JButton("Delete Ingredient");
        deleteIngredientButton.setBounds(new Rectangle(0, 0, 10, 20));
		deleteIngredientButton.setBounds(250, 190, 130, 30);
		add(deleteIngredientButton);

        deleteIngredientButton.addActionListener(event -> {
            String selectedIngredient = selectAnIngredient.getSelectedItem() + "";
            if (JOptionPane.showConfirmDialog(null, "Are you sure you want"
                    + " to delete " + selectedIngredient + "?", "Confirm Delete" , 
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                mealDatabase.removeIngredient(selectedMealID, selectedIngredient);
                JOptionPane.showMessageDialog(null, selectedIngredient + " successfully deleted!");
                removeAll();
				home.cancelPress();
            } 
		});
        
        editIngredientButton = new JButton("Edit Ingredient");
        editIngredientButton.setBounds(new Rectangle(0, 0, 10, 20));
		editIngredientButton.setBounds(250, 230, 130, 30);
		add(editIngredientButton);
        editIngredientButton.addActionListener(event -> {
            String selectedIngredient = selectAnIngredient.getSelectedItem() + "";
            System.out.println(selectedIngredient);
            editIngredient(selectedIngredient);
		});
        
        addIngredientButton = new JButton("Add Ingredient");
        addIngredientButton.setBounds(new Rectangle(0, 0, 10, 20));
		addIngredientButton.setBounds(150, 290, 130, 30);
		add(addIngredientButton);
        addIngredientButton.addActionListener(event -> {
             addIngredient();
		});
        
        validate();
        repaint();
    }
    
    void updateSelectedMeal(String newSelectedMeal) {
        selectedMeal = newSelectedMeal;
        selectedMealID = selectedMeal.substring(selectedMeal.lastIndexOf(' ') + 1);
        selectedMealName = mealDatabase.getMealName(selectedMealID);
        remove(editAMealProperty);
        remove(editAnIngredientProperty);
        remove(selectAMealProperty);
        remove(selectAnIngredientProperty);
        remove(selectAnIngredient);
        remove(changeMealProperty);
        remove(changeIngredientProperty);
        remove(deleteIngredientButton);
        remove(editIngredientButton);
        remove(addIngredientButton);
        remove(addIngredient);
        remove(ingredientAmountLabel);
        remove(ingredientMeasurementLabel);
        remove(ingredientLabel);
        remove(dataRow.getColumn(0));
		remove(dataRow.getColumn(1));
		remove(dataRow.getColumn(2));
        validate();
        repaint();
    }
    
    void addIngredient() {
        remove(deleteIngredientButton);
        remove(editIngredientButton);
        remove(addIngredientButton);
        remove(selectAnIngredient);
        dataRow = new MealDataRow(250);
        addTextPrompt("3", dataRow.getColumn(0));
        addTextPrompt("Apple", dataRow.getColumn(2));
		add(dataRow.getColumn(0));
		add(dataRow.getColumn(1));
		add(dataRow.getColumn(2));
        
        ingredientAmountLabel = new JLabel("Amount");
		ingredientAmountLabel.setBounds(20, 220, 65, 20);
		ingredientAmountLabel.setHorizontalAlignment(JLabel.CENTER);
        add(ingredientAmountLabel);
        
		ingredientMeasurementLabel = new JLabel("Measurement");
		ingredientMeasurementLabel.setBounds(95, 220, 83, 20);
		ingredientMeasurementLabel.setHorizontalAlignment(JLabel.CENTER);
        add(ingredientMeasurementLabel);
        
		ingredientLabel = new JLabel("Name (Singular Form)");
		ingredientLabel.setBounds(188, 220, 202, 20);
		ingredientLabel.setHorizontalAlignment(JLabel.CENTER);
        add(ingredientLabel);		
        
        addIngredient = new JButton("Add Ingredient");
        addIngredient.setBounds(new Rectangle(0, 0, 10, 20));
		addIngredient.setBounds(150, 290, 130, 30);
		add(addIngredient);
        addIngredient.addActionListener(event -> {
             finalizeAddIngredient(dataRow);
             if(addSuccess) {
                removeAll();
                home.cancelPress();
            }
		});
		
        validate();
        repaint();
    }
    
    void finalizeAddIngredient(MealDataRow mealDataRow) {
        try {
            if(Double.parseDouble(mealDataRow.getData(0)) < 0)
                throw new Exception();
            if(mealDataRow.getData(2).trim().isEmpty())
                throw new Exception();
            addSuccess = true;
         
        } catch(Exception e) {
            addSuccess = false;
            JOptionPane.showMessageDialog(null, "Ingredient amounts must be positive numbers"
                    + " and have a name!", "IO Error", JOptionPane.ERROR_MESSAGE);
        }
        
        if(addSuccess) {
            String ingredientAmountToAdd = mealDataRow.getData(0);
            String ingredientMeasurementToAdd = mealDataRow.getData(1);
            String ingredientToAdd = mealDataRow.getData(2);
            if (JOptionPane.showConfirmDialog(null, "Are you sure you want"
                        + " to add " + ingredientToAdd + " to " + selectedMealName + "?", 
                        "Confirm Change" , JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                mealDatabase.addIngredient(selectedMealID, ingredientAmountToAdd, ingredientMeasurementToAdd, ingredientToAdd);
                JOptionPane.showMessageDialog(null, ingredientToAdd + " successfully added!");
                removeAll();
                home.cancelPress();
            }          
        }
    }
    
    void editIngredient(String selectedIngredient) {
        remove(deleteIngredientButton);
        remove(editIngredientButton);
        remove(addIngredientButton);
        
        selectAnIngredientProperty = new JComboBox(mealDatabase.getEditableIngredientProperties(selectedMealID));
        selectAnIngredientProperty.setFont(new Font("Arial", Font.PLAIN, 12));
        selectAnIngredientProperty.setBounds(30, 260, 210, 60);
        selectAnIngredientProperty.setBorder(BorderFactory.createTitledBorder("Select Ingredient Property to Edit"));
        selectAnIngredientProperty.setBackground(Color.WHITE);
        selectAnIngredientProperty.addItem("-");
        selectAnIngredientProperty.setSelectedItem("-");
        add(selectAnIngredientProperty);
        selectAnIngredientProperty.addActionListener(event -> {
            String selectedProperty = selectAnIngredientProperty.getSelectedItem() + "";
            JOptionPane.showMessageDialog(null, "I'm still working on this part. Please explore other areas for now!");
            //editIngredientPropertyField(selectedIngredient);
        });
        
        validate();
        repaint();
    }
    /* Need to allow the user to edit an ingredient
    
    
    void editIngredientPropertyField(String selectedIngredient) {
        editAnIngredientProperty = new JTextField();
        editAnIngredientProperty.setBounds(30, 260, 210, 30);
        editAnIngredientProperty.setBackground(Color.WHITE);
        addTextPrompt("Current Value: " + mealDatabase.getPropertyValue(selectedMealID, selectedIngredient), editAnIngredientProperty);
        add(editAnIngredientProperty);
        
        remove(changeMealProperty);
        changeMealProperty = new JButton("Commit Change");
        changeMealProperty.setBounds(new Rectangle(0, 0, 10, 20));
		changeMealProperty.setBounds(250, 260, 130, 30);
		add(changeMealProperty);
        validate();
        repaint();
        
		changeMealProperty.addActionListener(event -> {
			String newProperty = editAMealProperty.getText().trim();
            try {
                if(selectedProperty.equalsIgnoreCase("duplicate") || 
                        selectedProperty.equalsIgnoreCase("favorite")) {
                    if(!newProperty.equalsIgnoreCase("true") &&
                            !newProperty.equalsIgnoreCase("false")) {
                        throw new Exception();
                    }
                }
                else if(selectedProperty.equalsIgnoreCase("calories")) 
                    Double.parseDouble(newProperty);
                else if(selectedProperty.equalsIgnoreCase("meal_of_day")) {
                    if(!newProperty.equalsIgnoreCase("breakfast") &&
                            !newProperty.equalsIgnoreCase("lunch") &&
                            !newProperty.equalsIgnoreCase("dinner"))
                        throw new Exception();
                }
                    
                if (JOptionPane.showConfirmDialog(null, "Are you sure you want"
                        + " to change " + selectedMealName + "'s " + 
                        selectedProperty.toLowerCase() + " property to " + newProperty + "?", 
                        "Confirm Change" , JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                    mealDatabase.editMealProperty(selectedMealID, selectedProperty, newProperty);
                    JOptionPane.showMessageDialog(null, selectedMealName + " successfully changed!");
                    removeAll();
                    home.cancelPress();
                }
            } catch(Exception e) {
                JOptionPane.showMessageDialog(null, newProperty + " is an incorrect format for " +
                       selectedProperty + "! " + selectedMealName + " unsuccessfully changed!");
            }
        });
    }
*/
}
