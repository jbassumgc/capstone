package Backend;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GeneratePlanScreenTest {

	@Test
	void testGeneratePlanScreen() {
		fail("Not yet implemented");
	}

	@Test
	void testGeneratePlan() {
		fail("Not yet implemented");
	}

}
