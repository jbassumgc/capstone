package Backend;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Database.MealDatabase;

class EnterMealScreenTest {
	MealDatabase mealdatabase;

	@Test
	void testEnterMealScreen() {
		fail("Not yet implemented");
	}

	@Test
	void testAddMeal() {
		
		fail("Not yet implemented");
	}

}
