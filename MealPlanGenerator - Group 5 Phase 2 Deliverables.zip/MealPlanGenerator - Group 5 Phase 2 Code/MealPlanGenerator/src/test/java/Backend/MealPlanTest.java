package Backend;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MealPlanTest {

	@Test
	void testMealPlan() {
		fail("Not yet implemented");
	}

	@Test
	void testGeneratePlan() {
		fail("Not yet implemented");
	}

	@Test
	void testGetShoppingList() {
		fail("Not yet implemented");
	}

}
