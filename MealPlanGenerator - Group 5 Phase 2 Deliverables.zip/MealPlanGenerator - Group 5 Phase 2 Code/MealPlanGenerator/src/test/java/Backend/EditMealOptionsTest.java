package Backend;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EditMealOptionsTest {

	@Test
	void testEditMealOptions() {
		fail("Not yet implemented");
	}

	@Test
	void testEditProperties() {
		fail("Not yet implemented");
	}

	@Test
	void testEditIngredients() {
		fail("Not yet implemented");
	}

}
