package Database;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DatabaseParserTest {

	@Test
	void testDatabaseParser() {
		fail("Not yet implemented");
	}

	@Test
	void testExportDatabase() {
		fail("Not yet implemented");
	}

	@Test
	void testImportDatabase() {
		fail("Not yet implemented");
	}

	@Test
	void testParseDatabase() {
		fail("Not yet implemented");
	}

}
